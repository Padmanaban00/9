package com.queryproject.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueryprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
